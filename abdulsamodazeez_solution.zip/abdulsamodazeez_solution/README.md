# Cassava AI Root Cause Detective — Solution Documentation
**Zindi user:** abdulsamodazeez | **Best submission ID: gCvbdQ1j** (public 0.996139)
Second selected submission: public 0.984556 (same architecture, alternate configuration)

## 1. Overview and Objectives
A single open-source model, Qwen/Qwen3-4B (Apache-2.0, 4B parameters), generates every
answer in the submission. The test set contains three question formats; each is routed
to the mode of the same model best suited to it:
- 82 general-knowledge (math) MCQs: the untouched base model, prompted in thinking
  mode, 12 seeded samples per question, majority vote. Using base weights guarantees
  knowledge retention by construction.
- 781 telemetry root-cause questions (two formats): the same model LoRA-fine-tuned on
  the provided train+validation labels, generating each answer by inference with
  self-consistency voting.
No deterministic or rule-based system outputs any answer; no cross-dataset lookups;
only the provided competition datasets are used.

## 2. Architecture
```
test.csv ─┬─ math questions ──────────► Qwen3-4B (base, thinking) ──► seeded 12-vote majority ─┐
          │                                                                                    ├─► submission.csv
          └─ telemetry questions ─► parser ─► feature verbalizer ─► prompt                     │   (4 identical rows
                                              (measurements only)   │                          │    per test ID)
   train/validation labels ─► SFT data (+synthetic scenarios) ─► LoRA fine-tune ─► Qwen3-4B ───┘
                                                                    (same model)   5-vote majority
```
Key design point: deterministic code performs PROMPT construction only (parsing tables,
computing measurements such as speeds, distances, tilt geometry, neighbor signal gaps,
and verbalizing them). The measurement-to-cause mapping is LEARNED by the model from
the provided labels; the model makes every decision.

## 3. ETL Process
- Extract: the five provided CSVs are read directly (auto-located in ./Data or
  /kaggle/input). Telemetry questions embed pipe- or markdown-format tables, parsed
  with regular expressions into structured records.
- Transform: per question, numeric features are computed (GPS speed, scheduled RBs,
  handover counts, UE-to-cell distance via haversine, downtilt/beamwidth coverage
  geometry, neighbor RSRP gaps, PCI mod-30 collisions, handover-threshold and PDCCH
  configuration values, signaling-event counts) and verbalized into a compact
  diagnostic summary that replaces the raw tables in the prompt.
- Load: SFT training records are written to JSONL (17k records: provided labels with
  feature-grounded rationales, option-shuffle augmentation matching the test formats,
  plus synthetic scenarios generated programmatically from the provided data's
  structure - no external data).

## 4. Data Modeling
- Base model: Qwen/Qwen3-4B (Apache-2.0; nominally 4B: 4.02B total / 3.6B
  non-embedding parameters, the standard nominal sizing convention).
- Fine-tuning: LoRA (r=16, alpha=32, dropout 0.05, all attention+MLP projections),
  3 epochs, lr 1e-4 cosine, effective batch 16, fp32 master weights with fp16
  autocast, prompt tokens masked from the loss, max length 1280. All seeds fixed.
- Validation: 200 validation IDs are excluded from training and used as an honest
  holdout, evaluated in both canonical and shuffled-option formats (printed in the
  notebook: 0.930 / 0.935). Note: the holdout is boundary-case-heavy relative to the
  test distribution, so it understates test accuracy.
- The evaluation metric (Pass@1 averaged over 4 rows per ID) makes one confident
  answer repeated 4x optimal; answer diversity strictly lowers expected score.

## 5. Inference
- Math: chat template with thinking enabled, temperature 0.6 / top-p 0.95 / top-k 20,
  num_return_sequences=12 after torch.manual_seed; answers taken only from the
  post-thinking segment (\\boxed{n} or Answer: n); majority vote.
- Telemetry: merged fine-tuned model in fp16, thinking disabled, 5 votes per question
  (1 greedy + 4 seeded samples), majority vote; the model's stated option label is
  extracted verbatim (handles the test set's shuffled/subset option labelings).
- Outputs: per-question vote tallies saved to pred_family3.json / pred_all.json;
  final submission.csv (3,452 rows).

## 6. Runtime Specifications (measured, NVIDIA H200, fp16)
- Data parsing + SFT data build: ~5 minutes (CPU)
- Math inference (82 questions x 12 samples, thinking): ~1.5-2 h
- LoRA fine-tune (3 epochs): 7,194 s (~2 h; exact value printed in the executed
  notebook's Trainer summary)
- Holdout evaluation (400 generations, batched): ~10 min
- Telemetry inference (781 questions x 5 votes): ~1 h
- Total: ~5 h end-to-end. Run order: single notebook, top to bottom.

## 7. Performance Metrics
- Best submission (ID gCvbdQ1j): public leaderboard 0.996139 (258/259).
- Second selected submission: public 0.984556.
- Holdout (200 unseen validation IDs): 0.930 canonical / 0.935 shuffled formats.
- The single public error is consistent with the one genuinely ambiguous class
  boundary (weak-coverage-at-far-end vs stronger-neighbor), documented below.

## 8. Error Handling and Logging
- Robust table parsing across both telemetry formats (pipe and markdown tables,
  section order variations); data-directory autodiscovery validates all five CSVs.
- Answer extraction retries with fresh seeds; a last-resort constant exists but
  artifact evidence shows it effectively never fired (all 82 math questions have
  non-empty model vote tallies; the alternate submission's executed notebook prints
  'telemetry non-model fallbacks used: 0' across all 781 questions under identical
  extraction code). Maintained source includes explicit fallback counters.
- All environment details (library versions, GPU) are printed by the notebook and
  preserved in the executed outputs. Incompatible preinstalled torchao is removed
  automatically by the setup cell.
- Known erratum: the opening docstring of the SFT-data cell still references an
  earlier 1.5B model iteration; the code loads and trains Qwen/Qwen3-4B as the
  printed outputs confirm. Executed notebooks are preserved byte-for-byte as run.

## 9. Maintenance and Monitoring
- Fully seeded: rerunning the notebook end-to-end regenerates the submission
  (identical on the same hardware class; majority voting makes results robust to
  cross-hardware sampling variance).
- The trained LoRA adapters (~120 MB) are available for exact-artifact verification:
  - main (0.996): https://drive.google.com/file/d/1m03BmlGmSY8FcwjBcTPb3d1VS6ukCVAF/view?usp=sharing
  - alternate (0.9846): https://drive.google.com/file/d/1ShA0pIURVZji2tOfPP9YbT0bUe2T8ZrB/view?usp=sharing
- Retraining on new labels = rerun the SFT-data and fine-tune cells; the adapter is
  the only stateful artifact and is versioned by the notebook run that produced it.

## How to Run (reproduction)
1. pip install -r requirements.txt (Python 3.12; GPU with >=40 GB VRAM recommended).
2. Place the five competition CSVs in a Data/ folder beside the notebook (or attach
   as a Kaggle dataset; auto-detected). The Google-Drive cell is the author's
   convenience and skips itself elsewhere.
3. Run submission_main_public_0.996/abdulsamodazeez_cassava_main.ipynb top to bottom
   -> submission.csv (3,452 rows), reproducing best submission gCvbdQ1j.
4. The included executed notebooks contain the full outputs of the scored runs for
   verification by inspection; submission CSVs and per-question prediction logs are
   included for verification by diff.

## Package Layout
- README.md (this file), requirements.txt
- submission_main_public_0.996/: executed notebook, submission.csv, pred_all.json,
  pred_family3.json  <- best submission gCvbdQ1j
- submission_alternate_public_0.9846/: same set for the second selected submission
